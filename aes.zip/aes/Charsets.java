package com.gsww.jzfp.utils.aes;

/**
 * 系统名称 xx平台
 * 工程名称 wy2-cloud
 * 创建时间 2017/8/1 10:20
 *
 * @author admin
 * @since 1.8
 */
public class Charsets {

    public final static String UTF8 = "utf-8";
}